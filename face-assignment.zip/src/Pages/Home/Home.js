import React from 'react';
import ContactList from '../ContactList/ContactList';
import Navbar from '../Navbar/Navbar';

const Home = () => {
    return (
        <div>

            <ContactList></ContactList>

        </div>
    );
};

export default Home;